Sample configuration files for:

SystemD: hellard.service
Upstart: hellard.conf
OpenRC:  hellard.openrc
         hellard.openrcconf
CentOS:  hellard.init
OS X:    org.hellar.hellard.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
